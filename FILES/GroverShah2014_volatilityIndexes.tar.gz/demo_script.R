library(ifrogs)
# Example 1: Construct confidence interval for Vega VIX using SPX options

set.seed(101)
# Read SPX options data for the two nearest maturities.
vix_spx <- read.csv("./vix_spx.csv", sep=",")
mat <- sort(unique(vix_spx$maturity))
spx_opt_near <- vix_spx[vix_spx$maturity %in% mat[1], ]
spx_opt_next <- vix_spx[vix_spx$maturity %in% mat[2], ]

# Preparing data for near and next month spx options without filtering
# options with zero traded volume.
spx_near <- prep_maturity(maturity=spx_opt_near$maturity[[1]],
                          riskfree=spx_opt_near$riskfree[[1]],
                          carry=spx_opt_near$riskfree[[1]],
                          type=spx_opt_near$type,
                          strike=spx_opt_near$strike,
                          underlying=spx_opt_near$underlying,
                          schemes="vega",
                          bid=spx_opt_near$bid,
                          ask=spx_opt_near$ask,
                          tv_filter=FALSE)

spx_next <- prep_maturity(maturity=spx_opt_next$maturity[[1]],
                          riskfree=spx_opt_next$riskfree[[1]],
                          carry=spx_opt_next$riskfree[[1]],
                          type=spx_opt_next$type,
                          strike=spx_opt_next$strike,
                          underlying=spx_opt_next$underlying,
                          schemes="vega",
                          bid=spx_opt_next$bid,
                          ask=spx_opt_next$ask,
                          tv_filter=FALSE)

# Confidence interval for Vega VIX
spx_ci <- vix_ci(prep_near=spx_near,
                 prep_next=spx_next,
                 n_samples=1e3, conf=0.95,
                 verbose=TRUE)

str(spx_ci)

# Point estimate
spx_ci$point

# Confidence interval
spx_ci$ci

# Bootstrap replicates
head(spx_ci$samples)

# Example 2: Compute Vega VIX using NIFTY options
set.seed(101)

# Read SPX options data for the two nearest maturities.
vix_nifty <- read.csv("./vix_nifty.csv", sep=",")
mat <- unique(vix_nifty$maturity)
nifty_opt_near <- vix_nifty[vix_nifty$maturity %in% mat[1], ]
nifty_opt_next <- vix_nifty[vix_nifty$maturity %in% mat[2], ]

# Preparing data for near and next month nifty options and filtering options
# with zero traded volume.
nifty_near <- prep_maturity(maturity=nifty_opt_near$maturity[[1]],
                            riskfree=nifty_opt_near$riskfree[[1]],
                            carry=nifty_opt_near$riskfree[[1]],
                            type=nifty_opt_near$type,
                            strike=nifty_opt_near$strike,
                            underlying=nifty_opt_near$underlying,
                            schemes="vega",
                            bid=nifty_opt_near$bid,
                            ask=nifty_opt_near$ask,
                            tv_filter=FALSE)

nifty_next <- prep_maturity(maturity=nifty_opt_next$maturity[[1]],
                            riskfree=nifty_opt_next$riskfree[[1]],
                            carry=nifty_opt_next$riskfree[[1]],
                            type=nifty_opt_next$type,
                            strike=nifty_opt_next$strike,
                            underlying=nifty_opt_next$underlying,
                            schemes="vega",
                            bid=nifty_opt_next$bid,
                            ask=nifty_opt_next$ask,
                            tv_filter=FALSE)

# Confidence interval for Vega VIX
nifty_ci <- vix_ci(prep_near=nifty_near,
                 prep_next=nifty_next,
                 n_samples=1e3, conf=0.95,
                 verbose=TRUE)

str(nifty_ci)

# Point estimate
nifty_ci$point

# Confidence interval
nifty_ci$ci

# Bootstrap replicates
head(nifty_ci$samples)
